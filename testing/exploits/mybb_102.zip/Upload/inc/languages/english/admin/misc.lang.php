<?php
$l['dbmaint'] = "Database Maintenance";
$l['proceed'] = "Proceed";
$l['dbmaint_notice'] = "When you run the DB maintenance function, the data in all tables of your database will be optimized and analyzed.";
$l['dbmaint_done'] = "All tables have successfully been optimized and analyzed.";

?>