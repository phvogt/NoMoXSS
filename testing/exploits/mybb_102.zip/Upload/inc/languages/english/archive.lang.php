<?php
$l['archive_fullversion'] = "Full Version:";
$l['archive_replies'] = "Replies";
$l['archive_reply'] = "Reply";
$l['archive_pages'] = "Pages:";
$l['archive_note'] = "You're currently viewing a stripped down version of our content.  <a href=\"{1}\">View the full version</a> with proper formatting.";
$l['archive_reference_urls'] = "Reference URL's";
$l['archive_nopermission'] = "Sorry but you do not have permission to access this resource.";
$l['error_nothreads'] = "There are currently no threads in this forum.";
?>