<?php
/*
 * Custom Help Section Translation Format
 *
 * // Help Section {sid}
 * $l['s{sid}_name'] = "Section name";
 * $l['s{sid}_desc'] = "Section description";
 */
?>