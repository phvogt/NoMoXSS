<?php
$l['nav_announcements'] = "Forum Announcement";
$l['announcements'] = "Announcement";
$l['forum_announcement'] = "Forum Announcement: {1}";
?>