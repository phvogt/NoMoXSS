<?php

$l['nav_memberlist'] = "Member List";

$l['member_list'] = "Member List";
$l['username'] = "Username:";
$l['email'] = "Email:";
$l['website'] = "Website:";
$l['location'] = "Location:";
$l['joined'] ="Joined:";
$l['posts'] = "Posts:";
$l['sort_by'] = "Sort by";
$l['sort_regdate'] = "registration date";
$l['sort_username'] = "username";
$l['sort_posts'] = "posts";
$l['sort_in'] = "in";
$l['sort_asc'] = "ascending";
$l['sort_desc'] = "descending";
$l['order'] = "order";
$l['search_for'] = "or search for user:";
$l['forumteam'] = "Show Forum Team";
?>