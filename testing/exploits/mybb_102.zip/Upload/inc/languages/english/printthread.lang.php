<?php
$l['forum'] = "Forum:";
$l['printable_version'] = "Printable Version";
$l['thread'] = "Thread:";
?>