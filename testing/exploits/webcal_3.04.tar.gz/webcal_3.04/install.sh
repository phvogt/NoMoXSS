#!/bin/sh

BASE=`pwd`
root="yes"
htaccess="yes"

#
# check command line for options
#
if [ "$1" = "-noroot" -o "$2" = "-noroot" ] ; then
	root="no"
fi
if [ "$1" = "-nohtaccess" -o "$2" = "-nohtaccess" ] ; then
	htaccess="no"
fi

#
# make sure root is running this.  We need root in order to change permissions
# properly and insert the crontab entry for messaging.
#
if [ $root = "yes" ] ; then
	user=`id | sed s/\).\*// | sed s/.\*\(//`
	if [ $user != "root" ] ; then
    	echo "you must be root to install!"
    	exit 0
	fi
fi

#
# where is perl
#
perl=`which perl`
if [ $? -ne 0 ] ; then
    perl="/usr/bin/perl"
fi
echo ""
printf "location of perl interpreter [$perl]: "
read ans
if [ $ans ] ; then
   perl=$ans
fi

#
# UID of webserver process
#
if [ $root = "yes" ] ; then
	uid="nobody"
	echo ""
	printf "User ID your webserver is running under [nobody]: "
	read ans
	if [ $ans ] ; then
    	uid=$ans
	fi
fi

#
# where the cgi scripts are to be kept
#
ht_home="/opt/httpd/cgi-bin/webcal"
echo ""
printf "Document Root for WebCal cgi's [$ht_home]: "
read ans
if [ $ans ] ; then
    ht_home=$ans
fi
cgi=$ht_home

#
# how to set the URL to access the cgi scripts
#
echo ""
doc_root="cgi-bin/webcal"
echo "I need to know how to get to your cgi-bin directory using a URL."
echo "If you are installing WebCal under the regular cgi-bin directory of your webserver, then the default should work.  If you are installing WebCal in a home directory then the string might be something like: \"~user/cgi-bin\"."
echo ""
printf "string to append to URL in order to reach cgi-bin dir [$doc_root]: "
read ans
if [ $ans ] ; then
    doc_root=$ans
fi

#
# where to store icons
#
icon_dir="/opt/httpd/icons"
echo ""
printf "Directory to store images needed [$icon_dir]: "
read ans
if [ $ans ] ; then
	icon_dir=$ans
fi
images="/icons"
echo ""
printf "Path to access thses images from webserver [$images]: "
read ans
if [ $ans ] ; then
	images=$ans
fi

#
# where to put the messaging script
#
rem_inst="y"
crontab="n"
echo ""
echo "Reminder script last updated in version 3.03."
printf "Install new reminder script [$rem_inst]: "
read ans
if [ $ans ] ; then
	rem_inst=$ans
fi
if [ $rem_inst = "y" ] ; then
	echo ""
	message_bin="/opt/local/bin"
	printf "where to put the messaging script [$message_bin]: "
	read ans
	if [ $ans ] ; then
    	message_bin=$ans
	fi
	#
	# whether to install the crontab entry for messaging
	#
	echo ""
	crontab="y"
	printf "should I install the crontab entry for you to enable messaging [$crontab]: "
	read ans
	if [ $ans ] ; then
		crontab=$ans
	fi
fi

#
# what type of database to use for the backend. 
#
db_type="flat"
echo ""
printf "database type (flat, mysql, postgresql) [$db_type]: "
read ans
if [ $ans ] ; then
	db_type=$ans
fi

#
# database back end setup.
#
if [ $db_type = "mysql" ] ; then
	db="webcal"
	db_table="webcal"
	db_user="webcal"
	db_pass="webcal"
	printf "MySQL database name [$db]: "
	read ans
	if [ $ans ] ; then
		db=$ans
	fi
	printf "MySQL table name [$db_table]: "
	read ans
	if [ $ans ] ; then
		db_table=$ans
	fi
	printf "MySQL database user [$db_user]: "
	read ans
	if [ $ans ] ; then
		db_user=$ans
	fi
	printf "MySQL password for $db_user [$db_pass]: "
	read ans
	if [ $ans ] ; then
		db_pass=$ans
	fi
	setup_mysql="n"
	printf "Do you need the initial mysql setup done? [$setup_mysql]: "
	read ans
	if [ $ans ] ; then
		setup_mysql=$ans
	fi
	if [ $setup_mysql = "y" ] ; then
		mysql_root="root"
		mysql_pass="mysql"
		mysql_bin=`which mysql 2>/dev/null`;
		if [ $? = "1" ] ; then
			mysql_bin=""
		fi
		printf "Full path to mysql binary: [$mysql_bin]: "
		read ans
		if [ $ans ] ; then
			mysql_bin=$ans
		fi 
		printf "MySQL root user [$mysql_root]: "
		read ans
		if [ $ans ] ; then
			mysql_root=$ans
		fi
		printf "MySQL passwd for $mysql_root [$mysql_pass]: "
		read ans
		if [ $ans ] ; then
			mysql_pass=$ans
		fi
		echo "Setting up MySQL...."
		cat mysql/mysql_setup.skel | sed -e "s/DB_NAME/$db/;s/DB_TABLE/$db_table/;s/DB_USER/$db_user/;s/DB_PASS/$db_pass/" > /tmp/setup.txt
		$mysql_bin -u $mysql_root -p${mysql_pass} < /tmp/setup.txt > /tmp/webcal_mysql_setup.log
		echo "Done! Check /tmp/webcal_mysql_setup.log for errors."
		/bin/rm -f /tmp/setup.txt
	else 
		echo "Your database should already be set up with the following: "
		echo "	database=$db  table=$db_table  user=$db_user  password=$db_pass"
	fi
elif [ $db_type = "postgresql" ] ; then
	echo ""
	db="webcal"
	db_user="0"
	db_pass="0"
	db_table="items"
	printf "PostgreSQL database name [$db]: "
	read ans
	if [ $ans ] ; then
		db=$ans
	fi
	create_db="n"
	printf "Do I need to create the database for you? [$create_db]: "
	read ans
	if [ $ans ] ; then
		create_db=$ans
	fi
	if [ $create_db = "y" ] ; then
		post_user="postgres"
		printf "PostgreSQL unix account [$post_user]: "
		read ans
		if [ $ans ] ; then
			post_user=$ans
		fi
		echo -n "creating PostgreSQL database $db... "
		/bin/cp postgresql/pg_setup.txt /tmp
		su -l $post_user -c "createdb $db ; psql -f /tmp/pg_setup.txt $db &> /tmp/pg_setup.log"
		echo "done (see /tmp/pg_setup.log for details)"
		/bin/rm /tmp/pg_setup.txt
	fi
elif [ $db_type = "flat" ] ; then
	db="none"
    db_user="0"
    db_pass="0"
	db_table="0"
	echo "Using flat file database system"
else
	echo "Unsupported database type: $db_type"
	exit
fi

#
# where to store the database files
#
echo ""
db_dir="/var/webcal"
if [ $db_type = "flat" ] ; then
	printf "where to store flat file databases [$db_dir]: "
else 
	printf "where to store extra webcal files [$db_dir]: "
fi
read ans
if [ $ans ] ; then
   	db_dir=$ans
fi
echo ""

#
# create whatever directories we need
#
if [ ! -d $ht_home ] ; then
    mkdir $ht_home
fi
if [ ! -d $db_dir ] ; then
   	mkdir -p $db_dir
fi
if [ $rem_inst = "y" ] ; then
	if [ ! -d $message_bin ] ; then
		mkdir -p $message_bin
	fi
fi
if [ ! -d $icon_dir ] ; then
    mkdir -p "$icon_dir"
fi

#
# install langauge files
#
echo "installing language scripts..."
echo ""
if [ -d "lang" ] ; then
	cd lang
else 
	echo "Error: no dir: lang"
	exit
fi
cp -f * $cgi
cd $BASE

#
# install the cgi scripts
#
if [ -d "bin" ] ; then
	cd bin
else 
	echo "Error: no dir: bin"
	exit
fi
echo "installing webcal scripts..."

echo "package webcal_conf;
my \$libdir = \"${cgi}\";

#
# Variables to be included for all WebCal cgi scripts...
# Variables for color, look, and feel are further down in this file
#

#
# Database variables, if not using flat files
#
\$DB = \"$db\";
\$DB_TABLE = \"$db_table\";
\$DB_USER = \"$db_user\";
\$DB_PASS = \"$db_pass\";

#
# HT_HOME: full unix path to the base html directory of your webserver.
#
\$HT_HOME = \"$ht_home\";

#
# DOC_ROOT: where are our cgi scripts located.  This directory should include
# the "protected" subdirectory, where the data operations cgi lives.
#
\$DOC_ROOT = \"$doc_root\";

#
# IMAGE_DIR: how to access images we need.
#
\$IMAGE_DIR = \"$images\";
\$ICON_DIR = \"$icon_dir\";

#
# DB_DIR: where subdirectories for each calendar are at.
#
\$DB_DIR = \"$db_dir\";
" > "${cgi}/webcal_conf.pm"
cat webcal_conf.pm >> "${cgi}/webcal_conf.pm"

echo "#!${perl}

use lib '${cgi}';
my \$libdir = \"${cgi}\";
my \$db_dir = \"$db_dir\";
" > "${cgi}/webcal.cgi"

cat webcal.cgi >> "${cgi}/webcal.cgi"

if [ ! -d "${cgi}/protected" ] ; then
    mkdir "${cgi}/protected"
fi

echo "#!${perl}

use lib '${cgi}';
my \$libdir = \"${cgi}\";
my \$db_dir = \"$db_dir\";
" > "${cgi}/protected/webcal2.cgi"

echo "#!${perl}

use lib '${cgi}';
my \$libdir = \"${cgi}\";
my \$db_dir = \"$db_dir\";
" > "${cgi}/protected/webcal_admin.cgi"

cat webcal2.cgi >> "${cgi}/protected/webcal2.cgi"
cat webcal_admin.cgi >> "${cgi}/protected/webcal_admin.cgi"

echo "#!${perl}

use lib '${cgi}';
my \$libdir = \"${cgi}\";
my \$db_dir = \"$db_dir\";
" > "${cgi}/protected/webcal_synch_server.cgi"

cat webcal_synch_server.cgi >> "${cgi}/protected/webcal_synch_server.cgi"

cp webcal_shared.pm "${cgi}/webcal_shared.pm"
cd $BASE

#
# install database access code
#
if [ -d "$db_type" ] ; then
	cd $db_type
else
	echo "Error: no dir: $db_type"
	exit
fi
cp "webcal_io_${db_type}.pm" "${cgi}/webcal_io.pm"
cd $BASE

#
# remove any old script if they are around
#
if [ -f "${cgi}/webcal_shared.pl" ] ; then
	/bin/rm -f "${cgi}/webcal_shared.pl"
fi
if [ -f "${cgi}/webcal.conf" ] ; then
	/bin/rm -f "${cgi}/webcal.conf"
fi

#
# set up messaging
#
if [ $rem_inst = "y" ] ; then
	if [ -f "${message_bin}/webcal_remind.pl" ] ; then
		echo "backing up old messaging script to webcal_remind.pl.old"
		cp -p "${message_bin}/webcal_remind.pl" "${message_bin}/webcal_remind.pl.old"
	fi
	echo "setting up messaging"
	echo "#!${perl}

use lib '${cgi}';
my \$libdir = \"${cgi}\";
my \$db_dir = \"$db_dir\";
" > "${message_bin}/webcal_remind.pl"
	if [ -d "bin" ] ; then
		cd bin
	else 
		echo "Error: no dir: bin"
		exit
	fi
	cat webcal_remind.pl >> "${message_bin}/webcal_remind.pl"
	cd $BASE
	touch "${db_dir}/message.log"
	if [ $crontab = "y" ] ; then
		crontab -l > /tmp/message.$$
		grep "webcal_remind" /tmp/message.$$ >/dev/null
		if [ $? -eq 1 ] ; then
			echo "#" >> /tmp/message.$$
			echo "# webcal messaging" >> /tmp/message.$$
			echo "#" >> /tmp/message.$$
			echo "0,5,10,15,20,25,30,35,40,45,50,55 * * * * ${message_bin}/webcal_remind.pl >> ${db_dir}/message.log 2>&1" >> /tmp/message.$$
			crontab /tmp/message.$$
			/bin/rm -f /tmp/message.$$
			echo "crontab updated"
		else
			echo "crontab already set up for messaging"
		fi
	fi
fi

#
# copy the images to their directory
#
if [ -d "images" ] ; then
	cd images
else
	echo "Error: no dir: images"
	exit
fi
cp -f dot_clear.gif *.jpg $icon_dir
if [ ! -f "${icon_dir}/text.gif" ] ; then
	cp -f text.gif $icon_dir
fi
if [ ! -f "${icon_dir}/bomb.gif" ] ; then
	cp -f bomb.gif $icon_dir
fi
cd $BASE

#
# set up the database
#
echo ""
echo "setting up database files..."

if [ $htaccess = "yes" ] ; then
	if [ ! -f "${db_dir}/.htpasswd" ] ; then
    	cp -f .htpasswd $db_dir
	fi
	tmp=`grep admin "${db_dir}/.htpasswd"`
	if [ ! -n "$tmp" ] ; then
    	cat .htpasswd.admin >> ${db_dir}/.htpasswd
	fi
	tmp=`grep nobody "${db_dir}/.htpasswd"`
	if [ ! -n "$tmp" ] ; then
    	cat .htpasswd.nobody >> ${db_dir}/.htpasswd
	fi
	tmp=`grep usholiday "${db_dir}/.htpasswd"`
	if [ ! -n "$tmp" ] ; then
    	cat .htpasswd.us.holiday >> ${db_dir}/.htpasswd
	fi
fi

# 
# US holiday calendar setup
#
if [ -d "dat" ] ; then
	cd dat
else
	echo "Error: no dir: dat"
	exit
fi
if [ ! -d "${db_dir}/US Holidays" ] ; then
	echo "Installing holiday calendar..."
	mkdir "${db_dir}/US Holidays"
	echo "usholiday" > "${db_dir}/US Holidays/.users"
	echo "This file is used by WebCal. Do not remove." > "${db_dir}/US Holidays/.public"
	cp -f us.holidays.cal.dat "${db_dir}/US Holidays/cal.dat"
fi
cd $BASE

#
# set up the .htaccess file
#
if [ $htaccess = "yes" ] ; then
	echo "AuthUserFile ${db_dir}/.htpasswd" > "${cgi}/protected/.htaccess"
	cat .htaccess >> "${cgi}/protected/.htaccess"
else
	cp admin.conf-no_htaccess "${db_dir}/admin.conf"
fi

#
# change permissions on files and directories
#
echo ""
echo "changing permissions..."
if [ $root = "yes" ] ; then
	chown $uid $db_dir
	chmod 700 $db_dir
	chown $uid "${db_dir}/.htpasswd"
	chmod 600 "${db_dir}/.htpasswd"
	chown -R $uid "${db_dir}/US Holidays"
	chmod -R 700 "${db_dir}/US Holidays"
	chown $uid "${cgi}/webcal"*
	chmod 755 "${cgi}/webcal.cgi"
	chmod 600 "${cgi}/webcal_conf.pm"
	chown -R $uid "${cgi}/protected"
	chmod -R 755 "${cgi}/protected"
else 
	chmod -R 755 $db_dir
	chmod -R 777 "${db_dir}/US Holidays"
	chmod 777 $db_dir
	chmod 644 "${cgi}/webcal"*
	chmod 755 "${cgi}/webcal.cgi"
	chmod -R 755 "${cgi}/protected"	
fi
if [ $rem_inst = "y" ] ; then
	chmod 755 "${message_bin}/webcal_remind.pl"
fi

#
# all done
#
echo ""
echo "installation complete."
echo ""
echo "The directory \"$cgi\" must be allowed to execute cgi script by your"
echo "http server.  See the README for assistance."
echo ""
echo "You can now start using WebCal by accessing the URL: "
echo "    http://<servername>/${doc_root}/webcal.cgi  OR"
echo "    https://<servername>/${doc_root}/webcal.cgi if using SSL"
echo ""

#
# reminder that db format is changed.
#
echo ""
echo "You have just installed WebCal version 3.04."
echo ""
echo "IMPORTANT: The database format has changed in version 3.02.  If you are"
echo "installing from scratch, you will be fine.  If you are installing over"
echo "a previous 3.01 or 3.0 WebCal installation, you will need to use the"
echo "db_convert.pl script in the utils directory to upgrade your database."
echo ""

exit 0

