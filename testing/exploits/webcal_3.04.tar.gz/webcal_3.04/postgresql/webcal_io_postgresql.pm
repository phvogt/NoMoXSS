# WebCal - a web based calendar program.
# Released under the GNU GPL.  A text version of the GPL should have come
# with this program in the file "GPL.txt".
# Copyright 1999 Michael Arndt
#

#
# This file contains perl subroutines used for data input and output.
# These subroutine are for use with PostGreSQL database
# Initial code contributed by Jean-Denis Girard <jd-girard@esoft.pf>.
# PostgreSQL setup has since been heavily modified by Michael Arndt.
#

package webcal_io;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(setup_items_hash del add_record del_calendar2 get_next_index set_all_unmodified input_check dbh_setup dbh_close);
use CGI;
use CGI::Carp qw(fatalsToBrowser);
use Time::Local;
use DBI;
use strict;

#
# Subroutine to set up the items hash
#
# Either we only get the items for a specific day, or we get the items for the entire
# month given, or we get the items for the current month plus the next month (for 
# reminder checking), or we get all the items.
#
sub setup_items_hash () {
	my ($type,$date) = (@_);
	my (%all_items,%sub_items,%pers_items,$index,$subindex,$modified,$user,$idate,$shour,$ehour,$string,$link,$rsec,@sub_cals,$misc_date,$sub_cal,$date2,$misc_date2);
	my ($q,$q2,$sth,$ref,%indexes,$x);
	$type = "all" if (! $type);
	if ($type eq "today") {
		$date = &webcal_shared::get_current if (! $date);
		if ($date =~ /(\d{4})(\d{2})(\d{2})/) {
			my $year = $1;
			my $month = $2;
			my $day = $3;
			my $time = timelocal 1,1,1,$day,($month-1),($year-1900);
			my $dow = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")[(localtime($time))[6]];
			$misc_date = "$year,$month,$day,$dow";
		}
		$q = "SELECT item_index FROM $::webcal_conf::DB_TABLE WHERE cal_name='$::calendar' AND (idate='$date' OR '$misc_date' ~ idate)";
	} elsif ($type eq "month") {
		if ($date =~ /^(\d{4})(\d{2})/) {
			my $year = $1;
			my $month = $2;
			$misc_date = "$year,$month";
		}
		$q = "SELECT item_index FROM $::webcal_conf::DB_TABLE WHERE cal_name='$::calendar' AND ('$date'=SUBSTR(idate,1,6) OR (idate ~ ',' AND '$misc_date' ~ SUBSTR(idate,'1',POSITION(',' in idate)+2)))";
	} elsif ($type eq "rem") {
		$date = &webcal_shared::get_current;
		if ($date =~ /(\d{4})(\d{2})(\d{2})/) {
			my $year = $1;
			my $month = $2;
			$date = $year.$month;
			$misc_date = "$year,$month";
			$month++;
			if ($month == 13) {
				$year++;
				$month = "01";
			}
			$month = "0".$month if ($month !~ /\d{2}/);
			$misc_date2 = "$year,$month";
			$date2 = $year.$month;
		}
		$date =~ s/^(\d{6})\d{2}/$1/;
		$q = "SELECT item_index FROM $::webcal_conf::DB_TABLE WHERE cal_name='$::calendar' AND ('$date'=SUBSTR(idate,1,6) OR '$date2'=SUBSTR(idate,1,6) OR (idate ~ ',' AND ('$misc_date' ~ SUBSTR(idate,'1',POSITION(',' in idate)+2) OR '$misc_date2' ~ SUBSTR(idate,'1',POSITION(',' in idate)+2))))";
	} elsif ($type eq "week") {
		$date = &webcal_shared::get_current if (! $date);
		if ($date =~ /(\d{4})(\d{2})(\d{2})/) {
			my $year = $1;
			my $month = $2;
			my $day = $3;
			$misc_date = "$year,$month";
			$date = $year.$month;
			if ($day < 7) {
				$month = $month - 1;
				if ($month == 0) {
					$year = $year - 1;
					$month = "12";
				}      
				$month = "0".$month if ($month !~ /\d{2}/);
				$misc_date2 = "$year,$month";
				$date2 = $year.$month;
			} elsif ($day > 22) {
				$month++;
				if ($month == 13) {
					$year++;
					$month = "01";
				}
				$month = "0".$month if ($month !~ /\d{2}/);
				$misc_date2 = "$year,$month";
				$date2 = $year.$month;
			} else {
				$misc_date2 = "99,99";
				$date2 = "9999";
			}
        }
		$q = "SELECT item_index FROM $::webcal_conf::DB_TABLE WHERE cal_name='$::calendar' AND ('$date'=SUBSTR(idate,1,6) OR '$date2'=SUBSTR(idate,1,6) OR (idate ~ ',' AND ('$misc_date' ~ SUBSTR(idate,'1',POSITION(',' in idate)+2) OR '$misc_date2' ~ SUBSTR(idate,'1',POSITION(',' in idate)+2))))";
	} else { 
		$q = "SELECT item_index FROM $::webcal_conf::DB_TABLE WHERE cal_name='$::calendar'";
	}
	$sth = $::dbh->prepare( $q ) or die $DBI::errstr;
	$sth->execute() or die $DBI::errstr;
	$q2 = "SELECT item_index, subindex, modified, cal_user, idate, shour, ehour, string, link, rsec, notes FROM $::webcal_conf::DB_TABLE WHERE cal_name='$::calendar' AND (";
	$x = 0;
	while ($ref = $sth->fetchrow_hashref()) {
		$index = $ref->{'item_index'};
		if (! $indexes{$index}) {
			if ($x) {
				$q2 .= " OR item_index = '$index'";
			} else {
				$q2 .= "item_index = '$index'";
			}
			$indexes{$index}++;
			$x++;
		}
	}
	$q2 .= ")";
	if ($x) {
		$sth = $::dbh->prepare( $q2 ) or die $DBI::errstr;
		$sth->execute() or die $DBI::errstr;
		while ($ref = $sth->fetchrow_hashref()) {
			$index = $ref->{'item_index'};
			$subindex = $ref->{'subindex'};
			$all_items{$index}{$subindex}{'modified'} = $pers_items{$index}{$subindex}{'modified'} = $ref->{'modified'};
			$all_items{$index}{$subindex}{'user'} = $pers_items{$index}{$subindex}{'user'} = $ref->{'user'};
			$all_items{$index}{$subindex}{'idate'} = $pers_items{$index}{$subindex}{'idate'} = $ref->{'idate'};
			$all_items{$index}{$subindex}{'shour'} = $pers_items{$index}{$subindex}{'shour'} = $ref->{'shour'};
			$all_items{$index}{$subindex}{'ehour'} = $pers_items{$index}{$subindex}{'ehour'} = $ref->{'ehour'};
			$all_items{$index}{$subindex}{'string'} = $pers_items{$index}{$subindex}{'string'} = $ref->{'string'};
			$all_items{$index}{$subindex}{'link'} = $pers_items{$index}{$subindex}{'link'} = $ref->{'link'};
			$all_items{$index}{$subindex}{'rsec'} = $pers_items{$index}{$subindex}{'rsec'} = $ref->{'rsec'};
			$all_items{$index}{$subindex}{'notes'} = $pers_items{$index}{$subindex}{'notes'} = $ref->{'notes'};
		}
	}
	@sub_cals = split(/\s+/,$::webcal_conf::SUBSCRIBE) if ($::webcal_conf::SUBSCRIBE);
	my $cal = $::calendar;
	for $sub_cal (@sub_cals) {
		next unless $sub_cal =~ /\w+/;
		undef %indexes;
		$sub_cal =~ s/\+/ /g;
		$q =~ s/$cal/$sub_cal/;
		$cal = $sub_cal;
		$sth = $::dbh->prepare( $q ) or die $DBI::errstr;
		$sth->execute() or die $DBI::errstr;
		$q2 = "SELECT item_index, subindex, modified, cal_user, idate, shour, ehour, string, link, rsec, notes FROM $::webcal_conf::DB_TABLE WHERE cal_name='$sub_cal' AND (";
		$x = 0;
		while ($ref = $sth->fetchrow_hashref()) {
			$index = $ref->{'item_index'};
			if (! $indexes{$index}) {
				if ($x) {
					$q2 .= " OR item_index = '$index'";
				} else {
					$q2 .= "item_index = '$index'";
				}
				$indexes{$index}++;
				$x++;
			}
		}
		$q2 .= ")";
		if ($x) {
			$sth = $::dbh->prepare( $q2 ) or die $DBI::errstr;
			$sth->execute() or die $DBI::errstr;
			while ($ref = $sth->fetchrow_hashref()) {
				$index = $ref->{'item_index'};
				$subindex = $ref->{'subindex'};
				$all_items{$index}{$subindex}{'modified'} = $sub_items{$index}{$subindex}{'modified'} = $ref->{'modified'};
				$all_items{$index}{$subindex}{'user'} = $sub_items{$index}{$subindex}{'user'} = $ref->{'user'};
				$all_items{$index}{$subindex}{'idate'} = $sub_items{$index}{$subindex}{'idate'} = $ref->{'idate'};
				$all_items{$index}{$subindex}{'shour'} = $sub_items{$index}{$subindex}{'shour'} = $ref->{'shour'};
				$all_items{$index}{$subindex}{'ehour'} = $sub_items{$index}{$subindex}{'ehour'} = $ref->{'ehour'};
				if ($::webcal_conf::SHOW_SUB_CAL_NAME) {
					$all_items{$index}{$subindex}{'string'} = $sub_items{$index}{$subindex}{'string'} = "<span class=sub-cal>$sub_cal</span> $ref->{'string'}";
				} else {
					$all_items{$index}{$subindex}{'string'} = $sub_items{$index}{$subindex}{'string'} = $ref->{'string'};
				}
				$all_items{$index}{$subindex}{'link'} = $sub_items{$index}{$subindex}{'link'} = $ref->{'link'};
				$all_items{$index}{$subindex}{'rsec'} = $sub_items{$index}{$subindex}{'rsec'} = $ref->{'rsec'};
				$all_items{$index}{$subindex}{'notes'} = $sub_items{$index}{$subindex}{'notes'} = $ref->{'notes'};
			}
		}
	}
	return (\%all_items,\%sub_items,\%pers_items);
}

#
# Subroutine to delete records from a database file.
#
sub del() {
	my ($index) = (@_);
	my ($line, $delete, $index2);
	my ($q,$sth,$rv);
	$q = "DELETE FROM $::webcal_conf::DB_TABLE WHERE item_index='$index' AND cal_name='$::calendar'";
	$sth = $::dbh->prepare( $q ) or die $DBI::errstr;
	$rv = $sth->execute() or die $DBI::errstr;
	return 1;
}

#
# Subroutine to add records to a database file.
#
sub add_record() {
	my ($index,$subindex,$user,$date,$stime,$etime,$string,$link_string,$rsec,$notes) = (@_);
	my ($q,$sth,$rv);
	$q = "INSERT INTO $::webcal_conf::DB_TABLE ( cal_name, item_index, subindex, modified, cal_user, idate, shour, ehour, string, link, rsec, notes ) VALUES ( '$::calendar', '$index', '$subindex', '1', '$user', '$date', '$stime', '$etime', '$string', '$link_string', '$rsec', '$notes' )";
	$sth = $::dbh->prepare( $q ) or die $DBI::errstr;
	$rv = $sth->execute() or die $DBI::errstr;
	return 1;
}

#
# subroutine to del all references to a calendar.
#
sub del_calendar2 () {
	my (@files,$dir);
	if (! $::calendar) {
		&webcal_shared::error_page("$webcal_conf::ERROR_STRING8");
	}
	$dir = "$webcal_conf::DB_DIR/$::calendar";
	opendir DIR, $dir or die "$webcal_conf::ERROR_STRING1 $dir: $!\n";
	@files = readdir DIR;
	closedir DIR;
	for (@files) {
		unlink("$dir/$_") if (-f "$dir/$_");
	}
	rmdir($dir) or die "$webcal_conf::ERROR_STRING28: $!\n";
	print "$webcal_conf::STRING110\n";
	&webcal_shared::print_footer("1");
	my $q = "DELETE FROM items WHERE cal_name='$::calendar'";
	my $sth = $::dbh->prepare( $q ) or die $DBI::errstr;
	my $rv  = $sth->execute or die $DBI::errstr;
	return 1;
}

#
# Subroutine to get next index to use.
#
sub get_next_index() {
	my ($q,$sth,$ref,@indexes,$next);
	$q = "SELECT item_index FROM $::webcal_conf::DB_TABLE";
	$sth = $::dbh->prepare( $q ) or die $DBI::errstr;
	$sth->execute() or die $DBI::errstr;
	while ($ref = $sth->fetchrow_hashref()) {
		push(@indexes,$ref->{'item_index'});
	}
	@indexes = sort {$a <=> $b} @indexes;
	$next = pop(@indexes);
	$next++;
	return $next;
}

#
# subroutine to set all items as unmodified for calendar after a synch
#
sub set_all_unmodified {
	my ($q,$sth,$rv);
	$q = "UPDATE $::webcal_conf::DB_TABLE set modified = '0' WHERE cal_name = '$::calendar'";
	$sth = $::dbh->prepare( $q ) or die $DBI::errstr;
	$rv = $sth->execute() or die $DBI::errstr;
	return 1;
}

#
# Subroutine to handle bad input for a flat file database.  If in a relational
# database module, a "'" will kill us on input, so lets get rid of it!
#
sub input_check() {
        my ($string) = (@_);
		$string =~ s/'/\\'/g;
        return $string;
}

#
# Subroutine to set up a database handle.
#
sub dbh_setup() {
	$::dbh = DBI->connect( "dbi:Pg:dbname=$::webcal_conf::DB",'nobody' ) or die $DBI::errstr;
	return 1;
}

#
# Subroutine to disconnect from database.
#
sub dbh_close() {
	$::dbh->disconnect;
	return 1;
}

